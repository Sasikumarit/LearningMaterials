## Summary

This is a demo project implementing OData server for Azure CosmosDB service using ExpressJS

## Tools & Libraries used

- JavaScript
- NodeJS
- ExpressJS
- OData
- @azure/cosmos

## Project Setup

### Start the server

```
yarn server
```

### Starting the client application

```
yarn start
```

### Creating sample data

After starting the application, the client will be running on http://localhost:3001 and the server will be running on http://localhost:5000/

You can visit the following url for results.
API
http://localhost:5000/api/data

Client
http://localhost:3001
